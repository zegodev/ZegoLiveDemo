//
//  ZegoNavigationController.h
//  LiveDemo2
//
//  Created by Randy Qiu on 4/13/16.
//  Copyright © 2016 Zego. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZegoNavigationController : UINavigationController

@end
