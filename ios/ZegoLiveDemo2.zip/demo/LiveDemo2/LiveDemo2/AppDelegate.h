//
//  AppDelegate.h
//  LiveDemo2
//
//  Created by Randy Qiu on 4/1/16.
//  Copyright © 2016 Zego. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

