//
//  ZegoAboutViewController.h
//  LiveDemo2
//
//  Created by Randy Qiu on 4/11/16.
//  Copyright © 2016 Zego. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZegoAboutViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end
