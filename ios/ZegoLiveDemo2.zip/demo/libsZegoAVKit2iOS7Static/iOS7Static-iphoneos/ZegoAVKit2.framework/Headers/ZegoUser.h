
#import <Foundation/Foundation.h>

@interface ZegoUser : NSObject

@property (nonatomic,retain) NSString *userID;

@property (nonatomic,retain) NSString *userName;

@end
